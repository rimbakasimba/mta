
/*
select * from starbucks.customer


 
declare @inputXml xml, @customField xml (customerSchema)

set @inputXml = '<Custom><Age>29</Age><State>NY</State></Custom>'
	
	select @customField = @inputXml
	
	print convert(varchar(500), @customField)
	
	*/
	
declare @emptyXsd xml
set @emptyXsd = '<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema"></xsd:schema>'
create xml schema collection StarBucks.emptySchema as  @emptyXsd

declare @inputXml xml, @customField xml (StarBucks.emptySchema)

set @inputXml = ''
select @customField = @inputXml

-- have a schema as xml (just to validate it)
-- the schema will have "null", "type", min,max etc
declare @customXsd xml
set @customXsd = '<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">
     <xsd:element name="Custom">
    <xsd:complexType>
      <xsd:sequence>
        <xsd:element name="Age" nillable="true" type="xsd:int" />	
        <xsd:element name="State" nillable="true" type="xsd:string" />
      </xsd:sequence>
    </xsd:complexType>
  </xsd:element>
   </xsd:schema>'
   
create xml schema collection customerSchema as  @customXsd


declare @custId uniqueidentifier
set @custId = '28136F19-F26D-4330-86E3-5DD8040B141B'
 
select * from starbucks.customer where id = @custId
exec UpdateCustomer @id = @custId, @name = 'Bam Bam',
     @CustomFields = '<Custom><Age>10</Age><State>Delhi</State></Custom>'
     
select * from starbucks.customer where id = @custId




create procedure UpdateCustomer (
	@id uniqueidentifier,
	@Name varchar(100) = null,
	@CustomFields xml = null
	)
as 
---- this will be taken from the credentials and not as any other output field
declare @passphrase varchar(100)
	set @passphrase = 'StarBucksUser'	

declare @validatedField xml (customerSchema)
select @validatedField = @CustomFields

update StarBucks.Customer
	set Name = EncryptByPassPhrase(@passphrase, ISNULL(@name, ''), 1, convert(varbinary, Id)) ,
		CustomFields = @validatedField
where id = @id
	