alter table [StarBucks].[Customer]
	add Name varbinary(100)		
	 
	insert into [StarBucks].[Customer] (Id, cardTypeId, createdOn, updatedOn, createdBy, updatedBy)
	values (newid(), 1, GETDATE(), GETDATE(), 13434, 13434 )
		
		declare @passphrase varchar(100)
	set @passphrase = 'StarBucksUser'		-- this will have guid of tenant
/*	
update [StarBucks].[Customer]
	set Name = EncryptByPassPhrase(@passphrase, 'Rimba', 1, convert(varbinary, Id)) 
where id = '51F23C08-0205-4B9A-BD2E-4D7D673032AC'
*/		
select id, Name from  [StarBucks].[Customer] 
where id = '51F23C08-0205-4B9A-BD2E-4D7D673032AC'

select convert(varchar, 
	DecryptByPassPhrase (@passphrase, Name, 1, convert(varbinary, Id)) )
from [StarBucks].[Customer] 
where id = '51F23C08-0205-4B9A-BD2E-4D7D673032AC'
